#[macro_use]
extern crate log;

pub mod extension;
pub mod prelude;

#[cfg(target_os = "windows")]
pub const PLUGIN_EXTENSION: &str = "dll";
#[cfg(target_os = "macos")]
pub const PLUGIN_EXTENSION: &str = "dylib";
#[cfg(any(target_os = "linux", target_os = "android"))]
pub const PLUGIN_EXTENSION: &str = "so";

/// Build an HTTP client with a TLS backend that works on this platform.
///
/// Android/Termux cannot use `rustls-platform-verifier` (it needs the Android
/// Java runtime to load the system trust store, and panics otherwise), so
/// Android falls back to the bundled Mozilla (webpki) roots. Other platforms
/// keep reqwest's default backend.
pub fn http_client() -> reqwest::Result<reqwest::Client> {
    #[cfg(not(target_os = "android"))]
    let builder = reqwest::Client::builder();

    #[cfg(target_os = "android")]
    let builder = {
        let mut roots = rustls::RootCertStore::empty();
        roots.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
        let config = rustls::ClientConfig::builder()
            .with_root_certificates(roots)
            .with_no_client_auth();
        reqwest::Client::builder().tls_backend_preconfigured(config)
    };

    builder.build()
}
