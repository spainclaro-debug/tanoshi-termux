#[macro_use]
extern crate log;

pub mod gotify;
pub mod pushover;
pub mod telegram;

use async_trait::async_trait;

/// Build a `reqwest` client with a TLS backend that works on this platform.
///
/// Android/Termux cannot use `rustls-platform-verifier` (it needs the Android
/// Java runtime to load the system trust store, and panics otherwise), so
/// Android falls back to the bundled Mozilla (webpki) roots. Other platforms
/// keep reqwest's default backend.
pub(crate) fn http_client() -> reqwest::Client {
    #[cfg(not(target_os = "android"))]
    let builder = reqwest::Client::builder();

    #[cfg(target_os = "android")]
    let builder = {
        let mut roots = rustls::RootCertStore::empty();
        roots.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
        let config = rustls::ClientConfig::builder()
            .with_root_certificates(roots)
            .with_no_client_auth();
        reqwest::Client::builder().tls_backend_preconfigured(config)
    };

    builder.build().unwrap_or_default()
}

#[async_trait]
pub trait Notifier {
    async fn send_notification(&self, user_key: &str, message: &str) -> Result<(), anyhow::Error>;

    async fn send_notification_with_title(
        &self,
        user_key: &str,
        title: &str,
        message: &str,
    ) -> Result<(), anyhow::Error>;

    async fn send_notification_with_title_and_url(
        &self,
        user_key: &str,
        title: &str,
        message: &str,
        url: &str,
        url_title: &str,
    ) -> Result<(), anyhow::Error>;
}
