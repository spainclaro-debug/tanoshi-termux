use async_trait::async_trait;
use tanoshi_tracker::{Session, TrackerManga};
use thiserror::Error;

use crate::domain::entities::tracker::{Token, TrackedManga, TrackerStatusUpdate};

#[derive(Debug, Error)]
pub enum TrackerRepositoryError {
    #[error("tracker not available")]
    NoTracker,
    #[error("tracker unauthorized")]
    Unauthorized,
    #[error("database return error: {0}")]
    DbError(#[from] sqlx::Error),
    #[error("other error: {0}")]
    Other(#[from] anyhow::Error),
}

#[async_trait]
pub trait TrackerRepository: Send + Sync {
    fn get_authorize_url(&self, tracker: &str) -> Result<Session, TrackerRepositoryError>;

    async fn exchange_code(
        &self,
        tracker: &str,
        code: String,
        state: Option<String>,
        csrf_state: Option<String>,
        pkce_code_verifier: Option<String>,
    ) -> Result<Token, TrackerRepositoryError>;

    async fn refresh_token(
        &self,
        tracker: &str,
        refresh_token: &str,
    ) -> Result<Token, TrackerRepositoryError>;

    async fn insert_tracker_credential(
        &self,
        user_id: i64,
        tracker: &str,
        token: Token,
    ) -> Result<(), TrackerRepositoryError>;

    async fn get_user_tracker_token(
        &self,
        tracker: &str,
        user_id: i64,
    ) -> Result<Token, TrackerRepositoryError>;

    async fn delete_user_tracker_login(
        &self,
        tracker: &str,
        user_id: i64,
    ) -> Result<u64, TrackerRepositoryError>;

    async fn search_manga(
        &self,
        token: &Token,
        tracker: &str,
        title: &str,
    ) -> Result<Vec<TrackerManga>, TrackerRepositoryError>;

    async fn get_tracked_manga_id(
        &self,
        user_id: i64,
        manga_id: i64,
    ) -> Result<Vec<TrackedManga>, TrackerRepositoryError>;

    async fn get_tracked_manga_id_by_manga_ids(
        &self,
        user_id: i64,
        manga_ids: &[i64],
    ) -> Result<Vec<TrackedManga>, TrackerRepositoryError>;

    async fn fetch_manga_details(
        &self,
        token: &str,
        tracker: &str,
        tracker_manga_id: i64,
    ) -> Result<TrackerManga, TrackerRepositoryError>;

    async fn update_manga_tracking_status(
        &self,
        token: &str,
        tracker: &str,
        tracker_manga_id: i64,
        update: TrackerStatusUpdate,
    ) -> Result<(), TrackerRepositoryError>;

    async fn update_tracker_manga_id(
        &self,
        user_id: i64,
        manga_id: i64,
        tracker: &str,
        tracker_manga_id: &str,
    ) -> Result<(), TrackerRepositoryError>;

    async fn delete_tracker_manga_id(
        &self,
        user_id: i64,
        manga_id: i64,
        tracker: &str,
    ) -> Result<(), TrackerRepositoryError>;
}
