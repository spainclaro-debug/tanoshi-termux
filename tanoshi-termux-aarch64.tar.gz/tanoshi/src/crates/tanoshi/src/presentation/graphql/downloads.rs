use super::{chapter::Chapter, common::Cursor, guard::AdminGuard};
use crate::{
    domain::services::download::DownloadService,
    infrastructure::{config::Config, domain::repositories::download::DownloadRepositoryImpl},
};
use async_graphql::{
    Context, Error, Object, Result, SimpleObject, Subscription,
    connection::{Connection, Edge, EmptyFields, query},
};
use chrono::Utc;
use futures::{Stream, StreamExt};
use rayon::iter::{IntoParallelIterator, ParallelIterator};

#[derive(Debug, SimpleObject)]
pub struct DownloadQueueEntry {
    pub source_id: i64,
    pub source_name: String,
    pub manga_id: i64,
    pub manga_title: String,
    pub chapter_id: i64,
    pub chapter_title: String,
    pub downloaded: i64,
    pub total: i64,
    pub priority: i64,
    pub date_added: i64,
}

impl From<crate::domain::entities::download::DownloadQueueEntry> for DownloadQueueEntry {
    fn from(queue: crate::domain::entities::download::DownloadQueueEntry) -> Self {
        Self {
            source_id: queue.source_id,
            source_name: queue.source_name,
            manga_id: queue.manga_id,
            manga_title: queue.manga_title,
            chapter_id: queue.chapter_id,
            chapter_title: queue.chapter_title,
            downloaded: queue.downloaded,
            total: queue.total,
            priority: queue.priority,
            date_added: queue.date_added.and_utc().timestamp(),
        }
    }
}

#[derive(SimpleObject)]
pub struct DownloadQueueUpdate {
    pub snapshot: bool,
    pub from_version: i64,
    pub version: i64,
    pub updates: Vec<DownloadQueueEntry>,
    pub removed_ids: Vec<i64>,
    pub resync_required: bool,
    pub download_status: bool,
}

#[derive(Default)]
pub struct DownloadSubscriptionRoot;

#[Subscription]
impl DownloadSubscriptionRoot {
    #[graphql(guard = "AdminGuard::new()")]
    async fn download_queue_updates(
        &self,
        ctx: &Context<'_>,
    ) -> Result<impl Stream<Item = DownloadQueueUpdate> + use<>> {
        let service = ctx.data::<DownloadService<DownloadRepositoryImpl>>()?;
        let path = std::path::PathBuf::from(&ctx.data::<Config>()?.download_path).join(".pause");
        let stream = service.subscribe_download_queue().await?;
        Ok(stream.map(move |update| {
            let outgoing = DownloadQueueUpdate {
                snapshot: update.snapshot,
                from_version: update.from_version,
                version: update.version,
                updates: update.updates.into_iter().map(Into::into).collect(),
                removed_ids: update.removed_ids,
                resync_required: update.resync_required,
                download_status: !path.exists(),
            };
            // Formatting and collecting chapter summaries happen only when
            // this log target has debug enabled.
            debug!(
                target: "tanoshi::download_queue",
                "queue outgoing: snapshot={} from_version={} version={} updates={} removed={} download_status={} resync_required={} chapters(id,downloaded,total,priority)={:?} removed_ids={:?}",
                outgoing.snapshot,
                outgoing.from_version,
                outgoing.version,
                outgoing.updates.len(),
                outgoing.removed_ids.len(),
                outgoing.download_status,
                outgoing.resync_required,
                outgoing.updates.iter().map(|row| (row.chapter_id, row.downloaded, row.total, row.priority)).collect::<Vec<_>>(),
                outgoing.removed_ids,
            );
            outgoing
        }))
    }
}

#[derive(Default)]
pub struct DownloadRoot;

#[Object]
impl DownloadRoot {
    async fn download_status(&self, ctx: &Context<'_>) -> Result<bool> {
        let download_path = &ctx.data::<Config>()?.download_path;

        let status = ctx
            .data::<DownloadService<DownloadRepositoryImpl>>()?
            .get_download_status(download_path);

        Ok(status)
    }

    #[graphql(guard = "AdminGuard::new()")]
    async fn download_queue(&self, ctx: &Context<'_>) -> Result<Vec<DownloadQueueEntry>> {
        let queue = ctx
            .data::<DownloadService<DownloadRepositoryImpl>>()?
            .get_download_queue(vec![])
            .await?
            .into_par_iter()
            .map(Into::into)
            .collect();

        Ok(queue)
    }

    #[graphql(guard = "AdminGuard::new()")]
    async fn get_downloaded_chapters(
        &self,
        ctx: &Context<'_>,
        after: Option<String>,
        before: Option<String>,
        first: Option<i32>,
        last: Option<i32>,
    ) -> Result<Connection<Cursor, Chapter, EmptyFields, EmptyFields>> {
        let download_svc = ctx.data::<DownloadService<DownloadRepositoryImpl>>()?;
        query(
            after,
            before,
            first,
            last,
            |after: Option<Cursor>, before: Option<Cursor>, first, last| async move {
                let after_cursor = after.unwrap_or_else(|| Cursor(Utc::now().timestamp(), 1));
                let before_cursor = before.unwrap_or(Cursor(0, 0));

                let edges = download_svc
                    .get_downloaded_chapters(
                        after_cursor.0,
                        after_cursor.1,
                        before_cursor.0,
                        before_cursor.1,
                        first,
                        last,
                    )
                    .await?;

                let mut has_previous_page = false;
                if let Some(e) = edges.first() {
                    has_previous_page = !download_svc
                        .get_downloaded_chapters(
                            Utc::now().timestamp(),
                            1,
                            e.date_added.and_utc().timestamp(),
                            e.id,
                            None,
                            Some(1),
                        )
                        .await?
                        .is_empty();
                }

                let mut has_next_page = false;
                if let Some(e) = edges.last() {
                    has_next_page = !download_svc
                        .get_downloaded_chapters(
                            e.date_added.and_utc().timestamp(),
                            e.id,
                            0,
                            0,
                            Some(1),
                            None,
                        )
                        .await?
                        .is_empty();
                }

                let mut connection = Connection::new(has_previous_page, has_next_page);
                connection.edges.extend(edges.into_iter().map(|e| {
                    Edge::new(
                        Cursor(e.uploaded.and_utc().timestamp(), e.id),
                        Chapter {
                            id: e.id,
                            source_id: e.source_id,
                            manga_id: e.manga_id,
                            title: e.title,
                            path: e.path,
                            number: e.number,
                            scanlator: e.scanlator,
                            uploaded: e.uploaded,
                            date_added: e.date_added,
                            read_progress: None,
                            downloaded_path: e.downloaded_path,
                            next: None,
                            prev: None,
                        },
                    )
                }));

                Ok::<_, Error>(connection)
            },
        )
        .await
    }
}

#[derive(Default)]
pub struct DownloadMutationRoot;

#[Object]
impl DownloadMutationRoot {
    /// Seed bogus queue entries for a manual responsiveness test. Pause downloads first.
    #[graphql(guard = "AdminGuard::new()")]
    async fn seed_download_queue_repro(
        &self,
        ctx: &Context<'_>,
        run_id: String,
        #[graphql(default = 5000)] chapters: i64,
        #[graphql(default = 30)] pages_per_chapter: i64,
    ) -> Result<Vec<i64>> {
        let service = ctx.data::<DownloadService<DownloadRepositoryImpl>>()?;
        if service.get_download_status(&ctx.data::<Config>()?.download_path) {
            return Err("Pause downloads before seeding a queue test".into());
        }
        Ok(service
            .seed_queue_repro(&run_id, chapters, pages_per_chapter)
            .await?)
    }

    /// Remove the remaining dummy entries belonging to one test run.
    #[graphql(guard = "AdminGuard::new()")]
    async fn clear_download_queue_repro(&self, ctx: &Context<'_>, run_id: String) -> Result<i64> {
        Ok(ctx
            .data::<DownloadService<DownloadRepositoryImpl>>()?
            .clear_queue_repro(&run_id)
            .await?)
    }

    async fn pause_download(&self, ctx: &Context<'_>) -> Result<bool> {
        let download_path = &ctx.data::<Config>()?.download_path;

        ctx.data::<DownloadService<DownloadRepositoryImpl>>()?
            .change_download_status(download_path, false)
            .await?;

        Ok(true)
    }

    async fn resume_download(&self, ctx: &Context<'_>) -> Result<bool> {
        let download_path = &ctx.data::<Config>()?.download_path;

        ctx.data::<DownloadService<DownloadRepositoryImpl>>()?
            .change_download_status(download_path, true)
            .await?;

        Ok(true)
    }

    #[graphql(guard = "AdminGuard::new()")]
    async fn download_chapters(&self, ctx: &Context<'_>, ids: Vec<i64>) -> Result<i64> {
        let len = ids.len() as i64;
        ctx.data::<DownloadService<DownloadRepositoryImpl>>()?
            .download_chapters(ids)
            .await?;

        Ok(len)
    }

    #[graphql(guard = "AdminGuard::new()")]
    async fn remove_chapters_from_queue(&self, ctx: &Context<'_>, ids: Vec<i64>) -> Result<i64> {
        let len = ids.len() as i64;
        ctx.data::<DownloadService<DownloadRepositoryImpl>>()?
            .remove_chapters_from_queue(ids)
            .await?;

        Ok(len)
    }

    #[graphql(guard = "AdminGuard::new()")]
    async fn remove_downloaded_chapters(&self, ctx: &Context<'_>, ids: Vec<i64>) -> Result<i64> {
        let len = ids.len() as i64;
        ctx.data::<DownloadService<DownloadRepositoryImpl>>()?
            .remove_downloaded_chapters(ids)
            .await?;

        Ok(len)
    }

    #[graphql(guard = "AdminGuard::new()")]
    async fn move_chapter_in_queue(&self, ctx: &Context<'_>, id: i64, up: bool) -> Result<bool> {
        ctx.data::<DownloadService<DownloadRepositoryImpl>>()?
            .move_chapter_in_queue(id, up)
            .await?;

        Ok(true)
    }
}
