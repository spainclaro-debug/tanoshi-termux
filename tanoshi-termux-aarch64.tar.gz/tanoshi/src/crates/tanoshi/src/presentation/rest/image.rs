use axum::{
    body::Body,
    extract::{Extension, Path, Query},
    http::{Response, StatusCode},
    response::IntoResponse,
};

use serde::Deserialize;

use crate::{
    domain::services::image::ImageService,
    infrastructure::{
        config::Config,
        domain::repositories::{image::ImageRepositoryImpl, image_cache::ImageCacheRepositoryImpl},
    },
};

#[derive(Debug, Deserialize)]
pub struct Params {
    source_id: i64,
}

pub async fn fetch_image(
    Path(encrypted_url): Path<String>,
    Query(params): Query<Params>,
    Extension(config): Extension<Config>,
    Extension(svc): Extension<ImageService<ImageCacheRepositoryImpl, ImageRepositoryImpl>>,
) -> Result<impl IntoResponse, StatusCode> {
    let image = svc
        .fetch_image(&config.secret, &encrypted_url, params.source_id)
        .await
        .map_err(|error| {
            // Surface the cause: the client only sees a 500, and without this
            // every image failure is invisible in the server log.
            log::warn!("image fetch failed for source {}: {error}", params.source_id);
            StatusCode::INTERNAL_SERVER_ERROR
        })?;

    Response::builder()
        .header("Content-Type", image.content_type)
        .header("Content-Length", image.data.len())
        .header("Cache-Control", "max-age=864000")
        .body(Body::from(image.data))
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)
}
